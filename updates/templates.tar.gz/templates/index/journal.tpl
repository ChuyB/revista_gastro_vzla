{**
 * templates/index/journal.tpl
 *
 * Copyright (c) 2013-2016 Simon Fraser University Library
 * Copyright (c) 2003-2016 John Willinsky
 * Distributed under the GNU GPL v2. For full terms see the file docs/COPYING.
 *
 * Journal index page.
 *
 *}
{strip}
{assign var="pageTitleTranslated" value=$siteTitle}
{include file="common/header.tpl"}
{/strip}

<div class="index-content-wrapper">
	{* REORDER: Move current issue to the top on mobile via CSS or reordering here *}
	{if $issue && $currentJournal->getSetting('publishingMode') != $smarty.const.PUBLISHING_MODE_NONE}
		<div id="currentIssueTop" class="mobile-top-issue">
			<h3>{$issue->getIssueIdentification()|strip_unsafe_html|nl2br}</h3>
			{include file="issue/view.tpl"}
		</div>
	{/if}

	<div class="other-index-content">
		{if $journalDescription}
			<div id="journalDescription">{$journalDescription}</div>
		{/if}

		{call_hook name="Templates::Index::journal"}

		{if $homepageImage}
		<br />
		<div id="homepageImage"><img src="{$publicFilesDir}/{$homepageImage.uploadName|escape:"url"}" width="{$homepageImage.width|escape}" height="{$homepageImage.height|escape}" {if $homepageImageAltText != ''}alt="{$homepageImageAltText|escape}"{else}alt="{translate key="common.journalHomepageImage.altText"}"{/if} /></div>
		{/if}

		{if $additionalHomeContent}
		<br />
		<div id="additionalHomeContent">{$additionalHomeContent}</div>
		{/if}

		{if $enableAnnouncementsHomepage}
			{* Display announcements *}
			<div id="announcementsHome">
				<h3>{translate key="announcement.announcementsHome"}</h3>
				{include file="announcement/list.tpl"}	
				<table class="announcementsMore">
					<tr>
						<td><a href="{url page="announcement"}">{translate key="announcement.moreAnnouncements"}</a></td>
					</tr>
				</table>
			</div>
		{/if}
	</div>
</div>

{include file="common/footer.tpl"}
