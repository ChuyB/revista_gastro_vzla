<?php

/**
 * @defgroup plugins_blocks_related_items
 */

/**
 * @file plugins/blocks/relatedItems/index.php
 *
 * Copyright (c) 2013-2016 Simon Fraser University Library
 * Copyright (c) 2003-2016 John Willinsky
 * Distributed under the GNU GPL v2. For full terms see the file docs/COPYING.
 *
 * @ingroup plugins_blocks_related_items
 * @brief Wrapper for related items block plugin.
 *
 */

require_once('RelatedItemsBlockPlugin.inc.php');

return new RelatedItemsBlockPlugin();

?>
